﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("6");
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("7");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn0_Click(object sender, EventArgs e)
        {
            MessageBox.Show("0");
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("1");
            
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("2");
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("3");
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("4");
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("5");
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("8");
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("9");
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("←");
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("/");
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("*");
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            MessageBox.Show("-");
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("+");
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("%");
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            MessageBox.Show("=");
        }

        private void btnVirgula_Click(object sender, EventArgs e)
        {
            MessageBox.Show(",");
        }
    }
}
