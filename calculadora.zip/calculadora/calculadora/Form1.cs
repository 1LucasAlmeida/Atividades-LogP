﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtN1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            float varNumeroUm = float.Parse(txtN1.Text);
            float varNumeroDois = float.Parse(txtN2.Text);
            float resultado;

            //soma 
            resultado = varNumeroUm + varNumeroDois;
            MessageBox.Show("soma = " + resultado);
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            float varNumeroUm = float.Parse(txtN1.Text);
            float varNumeroDois = float.Parse(txtN2.Text);
            float resultado;

            //subtração 
            resultado = varNumeroUm - varNumeroDois;
            MessageBox.Show("subtração = " + resultado);
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            float varNumeroUm = float.Parse(txtN1.Text);
            float varNumeroDois = float.Parse(txtN2.Text);
            float resultado;

            //multiplicação 
            resultado = varNumeroUm * varNumeroDois;
            MessageBox.Show("multiplicação = " + resultado);
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            float varNumeroUm = float.Parse(txtN1.Text);
            float varNumeroDois = float.Parse(txtN2.Text);
            float resultado;

            //divisão 
            resultado = varNumeroUm / varNumeroDois;
            MessageBox.Show("divisão = " + resultado);
        }
    }
}
