﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3Logica
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float BaseRetangulo = float.Parse(txtBaseRetangulo.Text);
            float AlturaRetangulo = float.Parse(txtAlturaRetangulo.Text);
            float Perimetro;
            Perimetro = BaseRetangulo * 2 + AlturaRetangulo * 2;
            lblResultado.Text = "O perímetro do retangulo é " + Perimetro;
        }
    }
}
