﻿namespace AppLista3Logica
{
    partial class FrmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTitulo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblBaseRetangulo = new System.Windows.Forms.Label();
            this.txtBaseRetangulo = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lblAlturaRetangulo = new System.Windows.Forms.Label();
            this.txtAlturaRetangulo = new System.Windows.Forms.TextBox();
            this.lblResultado = new System.Windows.Forms.Label();
            this.pnlTitulo.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTitulo
            // 
            this.pnlTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(7)))), ((int)(((byte)(8)))));
            this.pnlTitulo.Controls.Add(this.lblTitulo);
            this.pnlTitulo.Location = new System.Drawing.Point(1, 0);
            this.pnlTitulo.Margin = new System.Windows.Forms.Padding(6, 7, 6, 7);
            this.pnlTitulo.Name = "pnlTitulo";
            this.pnlTitulo.Size = new System.Drawing.Size(765, 105);
            this.pnlTitulo.TabIndex = 2;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Bernard MT Condensed", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(26)))), ((int)(((byte)(29)))));
            this.lblTitulo.Location = new System.Drawing.Point(95, 49);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(135, 31);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Exercicio 5";
            // 
            // lblBaseRetangulo
            // 
            this.lblBaseRetangulo.AutoSize = true;
            this.lblBaseRetangulo.Font = new System.Drawing.Font("Bernard MT Condensed", 20.25F, System.Drawing.FontStyle.Bold);
            this.lblBaseRetangulo.ForeColor = System.Drawing.Color.White;
            this.lblBaseRetangulo.Location = new System.Drawing.Point(96, 137);
            this.lblBaseRetangulo.Name = "lblBaseRetangulo";
            this.lblBaseRetangulo.Size = new System.Drawing.Size(233, 31);
            this.lblBaseRetangulo.TabIndex = 4;
            this.lblBaseRetangulo.Text = "Base do Retângulo:";
            // 
            // txtBaseRetangulo
            // 
            this.txtBaseRetangulo.Font = new System.Drawing.Font("Bernard MT Condensed", 20.25F, System.Drawing.FontStyle.Bold);
            this.txtBaseRetangulo.Location = new System.Drawing.Point(355, 134);
            this.txtBaseRetangulo.Name = "txtBaseRetangulo";
            this.txtBaseRetangulo.Size = new System.Drawing.Size(189, 40);
            this.txtBaseRetangulo.TabIndex = 7;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Bernard MT Condensed", 20.25F, System.Drawing.FontStyle.Bold);
            this.btnCalcular.Location = new System.Drawing.Point(212, 274);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(254, 47);
            this.btnCalcular.TabIndex = 8;
            this.btnCalcular.Text = "Calcular Perimetro";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lblAlturaRetangulo
            // 
            this.lblAlturaRetangulo.AutoSize = true;
            this.lblAlturaRetangulo.Font = new System.Drawing.Font("Bernard MT Condensed", 20.25F, System.Drawing.FontStyle.Bold);
            this.lblAlturaRetangulo.ForeColor = System.Drawing.Color.White;
            this.lblAlturaRetangulo.Location = new System.Drawing.Point(96, 205);
            this.lblAlturaRetangulo.Name = "lblAlturaRetangulo";
            this.lblAlturaRetangulo.Size = new System.Drawing.Size(248, 31);
            this.lblAlturaRetangulo.TabIndex = 9;
            this.lblAlturaRetangulo.Text = "Altura do Retângulo:";
            this.lblAlturaRetangulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtAlturaRetangulo
            // 
            this.txtAlturaRetangulo.Font = new System.Drawing.Font("Bernard MT Condensed", 20.25F, System.Drawing.FontStyle.Bold);
            this.txtAlturaRetangulo.Location = new System.Drawing.Point(355, 202);
            this.txtAlturaRetangulo.Name = "txtAlturaRetangulo";
            this.txtAlturaRetangulo.Size = new System.Drawing.Size(189, 40);
            this.txtAlturaRetangulo.TabIndex = 10;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Bernard MT Condensed", 20.25F, System.Drawing.FontStyle.Bold);
            this.lblResultado.ForeColor = System.Drawing.Color.White;
            this.lblResultado.Location = new System.Drawing.Point(231, 373);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 31);
            this.lblResultado.TabIndex = 11;
            // 
            // FrmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(26)))), ((int)(((byte)(29)))));
            this.ClientSize = new System.Drawing.Size(766, 450);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtAlturaRetangulo);
            this.Controls.Add(this.lblAlturaRetangulo);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtBaseRetangulo);
            this.Controls.Add(this.lblBaseRetangulo);
            this.Controls.Add(this.pnlTitulo);
            this.Name = "FrmExercicio5";
            this.Text = "FrmExercicio5";
            this.pnlTitulo.ResumeLayout(false);
            this.pnlTitulo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTitulo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblBaseRetangulo;
        private System.Windows.Forms.TextBox txtBaseRetangulo;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lblAlturaRetangulo;
        private System.Windows.Forms.TextBox txtAlturaRetangulo;
        private System.Windows.Forms.Label lblResultado;
    }
}