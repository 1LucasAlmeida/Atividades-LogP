﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista3Logica
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void lblPesoPrato_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float LadoQuadrado = float.Parse(txtLadoQuadrado.Text);
            float AreaQuadrado;
            AreaQuadrado = LadoQuadrado * LadoQuadrado;
            lblResultado.Text = "A área do quadrado é " + AreaQuadrado;
        }

        private void FrmExercicio4_Load(object sender, EventArgs e)
        {

        }
    }
}
